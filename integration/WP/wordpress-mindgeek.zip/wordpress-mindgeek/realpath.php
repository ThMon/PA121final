<?php echo realpath('index.php'); ?>
