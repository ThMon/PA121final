## Créer les catégories
1 catégorie parent (FAQ) et 4 catégories enfants
## FAQ
	— Actualités
	— Cloud
	— Hébergement dédié
	— Hébergement mutualisé
## Créer 5 articles (1 par catégorie)
## Installer les extensions
Site Origin Page Builder
Site Origin Widgets Bundle
Contact Form 7
