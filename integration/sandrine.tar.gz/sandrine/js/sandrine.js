console.log("pof");
let burger = document.querySelector(".toggle-menu");
//console.log(burger);
let navigation = document.querySelector(".nav-main");
//console.log(navigation);
function classToggle() {
    navigation.classList.toggle("nav-is-showing");
}
burger.addEventListener("click", classToggle);
