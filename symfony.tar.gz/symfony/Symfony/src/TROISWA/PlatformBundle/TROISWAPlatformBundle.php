<?php

namespace TROISWA\PlatformBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class TROISWAPlatformBundle extends Bundle
{
}
