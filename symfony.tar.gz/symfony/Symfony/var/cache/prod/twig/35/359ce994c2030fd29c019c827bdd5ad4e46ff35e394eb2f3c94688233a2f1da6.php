<?php

/* TROISWAPlatformBundle:Advert:index.html.twig */
class __TwigTemplate_2d2291fbcc84742d52112f8ebfce6f72d9c1aaa5bd1974b1c429c4d1627173f8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<html>
  <head>
    <title>Bienvenue sur ma première page avec OpenClassrooms !</title>
  </head>
  <body>
    <h1>Hello ";
        // line 7
        echo twig_escape_filter($this->env, ($context["nom"] ?? null), "html", null, true);
        echo "</h1>
    <p> l'url : ";
        // line 8
        echo twig_escape_filter($this->env, ($context[" url"] ?? null), "html", null, true);
        echo "</p>

    <p>
      Le Hello World est un grand classique en programmation.
      Il signifie énormément, car cela veut dire que vous avez
      réussi à exécuter le programme pour accomplir une tâche simple :
      afficher ce hello world !
    </p>
  </body>
</html>";
    }

    public function getTemplateName()
    {
        return "TROISWAPlatformBundle:Advert:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  31 => 8,  27 => 7,  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "TROISWAPlatformBundle:Advert:index.html.twig", "/home/wap32/sites/symfony/Symfony/src/TROISWA/PlatformBundle/Resources/views/Advert/index.html.twig");
    }
}
